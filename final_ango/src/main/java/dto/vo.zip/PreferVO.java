package vo;

public class PreferVO {

	private String cg_id;
	private String category_nm;
	private Float user_score;

	public String getCg_id() {
		return cg_id;
	}

	public void setCg_id(String cg_id) {
		this.cg_id = cg_id;
	}

	public Float getUser_score() {
		return user_score;
	}

	public void setUser_score(Float user_score) {
		this.user_score = user_score;
	}

	public String getCategory_nm() {
		return category_nm;
	}

	public void setCategory_nm(String category_nm) {
		this.category_nm = category_nm;
	}

	@Override
	public String toString() {
		return "PreferVO [cg_id=" + cg_id + ", category_nm=" + category_nm + ", user_score=" + user_score + "]";
	}

}
