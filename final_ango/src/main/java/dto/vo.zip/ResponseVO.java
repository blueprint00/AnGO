package vo;

import java.util.ArrayList;

public class ResponseVO {

	private int availability;
	private String token;
	private String response_msg;
	private ArrayList<QuestionVO> question_list;
	private ArrayList<ReviewVO> review_list;
	private ArrayList<PreferVO> prefer_list;
	private UserVO user;

	public int getAvailability() {
		return availability;
	}

	public void setAvailability(int availability) {
		this.availability = availability;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

	public String getResponse_msg() {
		return response_msg;
	}

	public void setResponse_msg(String response_msg) {
		this.response_msg = response_msg;
	}


	public ArrayList<QuestionVO> getQuestion_list() {
		return question_list;
	}

	public void setQuestion_list(ArrayList<QuestionVO> question_list) {
		this.question_list = question_list;
	}

	public ArrayList<ReviewVO> getReview_list() {
		return review_list;
	}

	public void setReview_list(ArrayList<ReviewVO> review_list) {
		this.review_list = review_list;
	}

	public ArrayList<PreferVO> getPrefer_list() {
		return prefer_list;
	}

	public void setPrefer_list(ArrayList<PreferVO> prefer_list) {
		this.prefer_list = prefer_list;
	}

	public UserVO getUser() {
		return user;
	}

	public void setUser(UserVO user) {
		this.user = user;
	}

	@Override
	public String toString() {
		return "ResponseVO [availability=" + availability + ", token=" + token + ", response_msg=" + response_msg
				+ ", question_list=" + question_list + ", review_list=" + review_list + ", prefer_list=" + prefer_list
				+ ", user=" + user + "]";
	}



}
